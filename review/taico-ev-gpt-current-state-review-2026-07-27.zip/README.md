# TAICO EV Website Project

English B2B website for **TAICO EV** — mobile EV charging and energy solutions, brand domain `taicoev.com`.

## Decisions (locked)

| Item | Choice |
|------|--------|
| Brand site | Independent: `taicoev.com` (not a product tab under taicopower.com) |
| Stack | Astro + TypeScript + Tailwind CSS |
| Hosting | GitHub + Cloudflare Pages (later) |
| Language v1 | English only |
| Positioning | Solutions first, product models second |

Brand line:

> **Power Electric Mobility Beyond the Grid.**

## Folder map

```text
.
├── docs/           # Strategy, handoff, catalogs, case sources
├── assets/images/  # Source photos (not yet optimized for web)
├── website/        # Astro site source code
├── AGENTS.md       # Rules for AI / human collaborators
└── README.md       # This file
```

## Key docs

- `docs/新手说明-项目做了什么.md` — **beginner walkthrough (中文)**：做了什么、文件夹、怎么预览
- `docs/handoff.md` — full project brief (IA, SEO, stack, page plan)
- `docs/CLOUDFLARE_DEPLOY_HANDOFF.md` — Cloudflare deploy troubleshooting (for Codex)
- `docs/TAICO_Mobile_Charging_Strategy.md` — market strategy
- Product catalogs & cases under `docs/`
- `DEPLOY.md` — production deploy steps

## Local website (after scaffold)

```sh
cd website
npm install
npm run dev
```

Open the URL printed in the terminal (usually `http://localhost:4321`).

## Deploy

| Item | Status |
|------|--------|
| GitHub | ✅ private `https://github.com/miesrock/taico-ev-website` |
| Cloudflare Pages | ⏳ connect Git + first deploy (see `DEPLOY.md`) |
| Domain `taicoev.com` | ⏳ attach after Pages project exists |

```sh
# after local edits
git add -A && git commit -m "update: ..." && git push
```

## Roadmap (current stage)

1. [x] Align project decisions
2. [x] Organize folders + copy handoff
3. [x] Scaffold Astro + Tailwind
4. [x] Layout shell + Home placeholder
5. [x] Visual system (Analogue Waves / dark tech) + catalog-backed solution pages
6. [x] Product pages for the eight TKMC Catalog v1.3 models
7. [x] Catalog-backed application and comparison pages
8. [x] GitHub repo created + code pushed
9. [ ] Cloudflare Pages connect + first deploy
10. [ ] Domain DNS `taicoev.com`
11. [ ] Real contact form
